/* Yash: yet another shell */
/* © 2007 magicant */

/* This software can be redistributed and/or modified under the terms of
 * GNU General Public License, version 2 or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRENTY. */


#define _GNU_SOURCE
#include <error.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <sys/types.h>
#include "yash.h"
#include <assert.h>

#ifndef NDEBUG
#include <fcntl.h>
#endif


void *trycalloc(size_t nmemb, size_t size);
void *trymalloc(size_t size);
void *tryrealloc(void *ptr, size_t size);
char *strclone(const char *s, ssize_t len);
char **straryclone(char **ary);
void redirsfree(REDIR *redirs, size_t count);
void scmdsfree(SCMD *scmds, size_t count);
void setsigaction(void);
void exec_file(const char *path, int suppresserror);
void exec_file_exp(const char *path, int suppresserror);
static void init_env(void);
void interactive_loop(void);
int main(int argc, char **argv);
void yash_exit(int exitcode);

#ifndef NDEBUG
void print_scmds(SCMD *scmds, int count, int indent);
#endif

/* このプロセスがログインシェルなら非 0 */
int is_loginshell;
/* 対話的シェルなら非 0 */
int is_interactive;

/* calloc を試みる。失敗したらエラーを出力する。
 * 戻り値: calloc の結果 */
void *trycalloc(size_t nmemb, size_t size)
{
	void *result = calloc(nmemb, size);
	if (!result)
		error(0, 0, "memory shortage");
	return result;
}

/* malloc を試みる。失敗したらエラーを出力する。
 * 戻り値: malloc の結果 */
void *trymalloc(size_t size)
{
	void *result = malloc(size);
	if (!result)
		error(0, 0, "memory shortage");
	return result;
}

/* realloc を試みる。失敗したら元の領域を解放してエラーを出力する。
 * 戻り値: realloc の結果 */
void *tryrealloc(void *ptr, size_t size)
{
	void *result = realloc(ptr, size);
	if (!result) {
		error(0, 0, "memory shortage");
		free(ptr);
	}
	return result;
}

/* 文字列を新しく malloc した領域に複製する。
 * malloc に失敗すると NULL を返す。
 * len: 文字列の長さ ('\0' を含まない)。負数を指定すると文字列全体を複製。 */
char *strclone(const char *s, ssize_t len)
{
	char *result;

	if (len < 0)
		len = strlen(s);
	result = trymalloc(len + 1);
	if (!result)
		return NULL;
	strncpy(result, s, len);
	result[len] = '\0';
	return result;
}

/* 文字列の配列のディープコピーを作る。
 * 失敗すると NULL を返す。 */
char **straryclone(char **ary)
{
	size_t count, i;
	char **result;

	assert(ary);
	for (count = 0; ary[count]; count++) ;
	result = trycalloc(count + 1, sizeof(char *));
	if (!result)
		return NULL;
	for (i = 0; i < count; i++) {
		if (!(result[i] = strclone(ary[i], -1)))
			goto error;
	}
	return result;

error:
	count = i;
	for (i = 0; i < count; i++)
		free(result[i]);
	free(result);
	return NULL;
}

/* 指定した配列にある各 REDIR の内部のメモリを解放する。
 * 配列そのものは解放しない。
 * redirs: REDIR の配列へのポインタ
 * count:  配列の要素数 */
void redirsfree(REDIR *redirs, size_t count)
{
	for (size_t i = 0; i < count; i++) {
		free(redirs[i].rd_file);
	}
}

/* 指定した配列にある各 SCMD の内部のメモリを解放する。
 * 配列そのものは解放しない。
 * scmds: SCMD の配列へのポインタ
 * count: 配列の要素数 */
void scmdsfree(SCMD *scmds, size_t count)
{
	for (ssize_t i = 0; i < count; i++) {
		SCMD *scmd = scmds + i;
		char **argv = scmd->c_argv;

		if (argv) {
			for (char **a = argv; *a; a++)
				free(*a);
			free(argv);
		} else {
			scmdsfree(scmd->c_subcmds, scmd->c_argc);
		}
		redirsfree(scmd->c_redir, scmd->c_redircnt);
		free(scmd->c_name);
	}
}

/* 無視するシグナルのリスト */
const int ignsignals[] = {
	SIGINT, SIGQUIT, SIGTERM, SIGTSTP, SIGTTIN, SIGTTOU, 0,
};

void debug_sig(int signal)
{
	error(0, 0, "DEBUG: received signal %d. pid=%d", signal, (int) getpid());
}

/* シグナルハンドラを初期化する */
void setsigaction(void)
{
	struct sigaction action;
	const int *signals;

	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;
#if 0
	action.sa_handler = debug_sig;
	fprintf(stderr, "DEBUG: setting all sigaction\n");
	for (int i = 1; i < 32; i++)
		if (sigaction(i, &action, NULL) < 0) ;
#endif

	action.sa_handler = SIG_IGN;
	signals = ignsignals;
	for (signals = ignsignals; *signals; signals++)
		if (sigaction(*signals, &action, NULL) < 0)
			error(0, errno, "sigaction: signal=%d", *signals);

	action.sa_handler = SIG_DFL;
	if (sigaction(SIGCHLD, &action, NULL) < 0)
		error(0, errno, "sigaction: signal=SIGCHLD");

	action.sa_handler = sig_hup;
	action.sa_flags = SA_RESETHAND;
	if (sigaction(SIGHUP, &action, NULL) < 0)
		error(0, errno, "sigaction: signal=SIGHUP");
}

/* シグナルハンドラを元に戻す */
void resetsigaction(void)
{
	struct sigaction action;
	const int *signals;

	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;

	action.sa_handler = SIG_DFL;
	signals = ignsignals;
	for (signals = ignsignals; *signals; signals++)
		if (sigaction(*signals, &action, NULL) < 0)
			error(0, errno, "sigaction: signal=%d", *signals);
	if (sigaction(SIGHUP, &action, NULL) < 0)
		error(0, errno, "sigaction: signal=SIGHUP");
}

/* 指定したファイルをシェルスクリプトとして実行する
 * suppresserror: 非 0 なら、ファイルが読み込めなくてもエラーを出さない */
void exec_file(const char *path, int suppresserror)
{
	FILE *file = fopen(path, "r");
	char *line = NULL;
	size_t len = 0;
	ssize_t size;

	if (!file) {
		if (!suppresserror)
			error(0, errno, "%s", path);
		return;
	}
	while ((size = getline(&line, &len, file)) >= 0) {
		SCMD *scmds;
		ssize_t count;
		
		if (line[size - 1] == '\n')
			line[size - 1] = '\0';
		count = parse_line(line, &scmds);
		if (count < 0)
			continue;
		exec_list(scmds, count);
		scmdsfree(scmds, count);
		free(scmds);
	}
	free(line);
	fclose(file);
}

/* ファイルをシェルスクリプトとして実行する。
 * path: ファイルのパス。'~' で始まるならホームディレクトリを展開して
 *       ファイルを探す。 */
void exec_file_exp(const char *path, int suppresserror)
{
	if (path[0] == '~') {
		char *newpath = expand_tilde(path);
		if (!newpath)
			return;
		exec_file(newpath, suppresserror);
		free(newpath);
	} else {
		exec_file(path, suppresserror);
	}
}

/* 実行環境を初期化する */
static void init_env(void)
{
	char *path = getcwd(NULL, 0);

	if (path) {
		char *spwd = collapse_homedir(path);

		if (setenv(ENV_PWD, path, 1 /* overwrite */) < 0)
			error(0, 0, "failed to set env PWD");
		if (spwd) {
			if (setenv(ENV_SPWD, spwd, 1 /* overwrite */) < 0)
				error(0, 0, "failed to set env SPWD");
			free(spwd);
		}
		free(path);
	}
}

/* 対話的動作を行う。この関数は返らない。 */
void interactive_loop(void)
{
	char *line;
	SCMD *scmds;
	ssize_t count;

	initialize_readline();
	for (;;) {
		switch (yash_readline(&line)) {
			case -2:  /* EOF */
				printf("\n");
				wait_all(-2 /* non-blocking */);
				print_all_job_status(0 /* all jobs */, 0 /* not verbose */);
				if (job_count()) {
					error(0, 0, "There are undone jobs!"
							"  Use `exit -f' to exit forcibly.");
					continue;
				}
				goto exit;
			case -1:
				continue;
			case 0:  default:
				break;
		}
		/* printf("parsing \"%s\"\n", line); */
		count = parse_line(line, &scmds);
		if (count < 0)
			continue;

		/* printf("count=%d\n", count); */
		/* print_scmds(scmds, count, 0); */
		exec_list(scmds, count);
		scmdsfree(scmds, count);
		free(scmds);
		free(line);
	}
exit:
	yash_exit(laststatus);
}

#ifndef NDEBUG

void print_scmds(SCMD *scmds, int count, int indent)
{
	void print_indent(int i) {
		printf("%*s", i, "");
	}
	int i, j;

	for (i = 0; i < count; i++) {
		print_indent(indent);
		printf("SCMD[%d] : ", i);
		switch (scmds[i].c_type) {
			case CT_END:   printf("END\n");   break;
			case CT_PIPED: printf("PIPED\n"); break;
			case CT_BG:    printf("BG\n");    break;
			case CT_AND:   printf("AND\n");   break;
			case CT_OR:    printf("OR\n");    break;
		}
		if (scmds[i].c_argv)
			for (j = 0; j < scmds[i].c_argc; j++) {
				print_indent(indent);
				printf("  Arg   %d : %s\n", j, scmds[i].c_argv[j]);
			}

		for (j = 0; j < scmds[i].c_redircnt; j++) {
			print_indent(indent);
			printf("  Redir %d : fd=%d file=\"%s\" ", j,
					scmds[i].c_redir[j].rd_fd, scmds[i].c_redir[j].rd_file);
			if (scmds[i].c_redir[j].rd_flags & O_RDWR)        printf("RDWR");
			else if (scmds[i].c_redir[j].rd_flags & O_WRONLY) printf("WRONLY");
			else                                               printf("RDONLY");
			if (scmds[i].c_redir[j].rd_flags & O_CREAT)  printf(" CREAT");
			if (scmds[i].c_redir[j].rd_flags & O_APPEND) printf(" APPEND");
			if (scmds[i].c_redir[j].rd_flags & O_TRUNC)  printf(" TRUNC");
			printf("\n");
		}
		print_indent(indent);
		printf("  Name    : %s\n", scmds[i].c_name);
		
		if (scmds[i].c_subcmds)
			print_scmds(scmds[i].c_subcmds, scmds[i].c_argc, indent + 8);
	}
}

#endif

int main(int argc, char **argv)
{
	int noprofile = 0, norc = 0, help = 0, version = 0;
	int opt, index;
	char *rcfile = "~/.yashrc", *directcommand = NULL;
	static const char *short_opts = "c:il";
	static struct option long_opts[] = {
		{ "help", 0, NULL, 'h', },
		{ "version", 0, NULL, 'v' + 256, },
		{ "rcfile", 1, NULL, 'r', },
		{ "noprofile", 0, NULL, 'N' + 256, },
		{ "norc", 0, NULL, 'n' + 256, },
		{ "login", 0, NULL, 'l', },
		{ "interactive", 0, NULL, 'i', },
		{ NULL, 0, NULL, 0, },
	};

	is_loginshell = argv[0][0] == '-';
	is_interactive = 1;
	if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO))
		is_interactive = 0;
	setsigaction();
	joblistlen = 2;
	joblist = trycalloc(joblistlen, sizeof(JOB));
	if (!joblist)
		return EXIT_FAILURE;

	optind = 0;
	opterr = 1;
	while ((opt = getopt_long(argc, argv, short_opts, long_opts, &index)) >= 0){
		switch (opt) {
			case 0:
				break;
			case 'c':
				directcommand = optarg;
				break;
			case 'h':
				help = 1;
				break;
			case 'i':
				is_interactive = 1;
				break;
			case 'l':
				is_loginshell = 1;
				break;
			case 'n' + 256:
				norc = 1;
				break;
			case 'N' + 256:
				noprofile = 1;
				break;
			case 'r':
				rcfile = optarg;
				break;
			case 'v' + 256:
				version = 1;
				break;
			default:
				return EXIT_FAILURE;
		}
	}
	if (help) {
		printf("Usage:  yash [-il] [-c command] [long options] [file]\n");
		printf("Long options:\n");
		for (index = 0; long_opts[index].name; index++)
			printf("\t--%s\n", long_opts[index].name);
		return EXIT_SUCCESS;
	} else if (version) {
		printf("Yet another shell, version " YASH_VERSION "\n");
		printf(YASH_COPYRIGHT "\n");
		return EXIT_SUCCESS;
	}

	init_env();
	if (directcommand) {
		SCMD *scmds;
		ssize_t count;
		
		is_interactive = 0;
		count = parse_line(directcommand, &scmds);
		if (count < 0)
			return EXIT_SUCCESS;
		exec_list(scmds, count);
		scmdsfree(scmds, count);
		free(scmds);
		return laststatus;
	}

	if (is_interactive) {
		if (is_loginshell) {
			if (!noprofile)
				exec_file_exp("~/.yash_profile", 1 /* suppress error */);
		} else if (!norc) {
			exec_file_exp(rcfile, 1 /* suppress error */);
		}
		interactive_loop();
	}
	return laststatus;
}

/* 終了前の手続きを行って、終了する。*/
void yash_exit(int exitcode) {
	if (is_loginshell)
		exec_file("~/.yash_logout", 1);
	finalize_readline();
	exit(exitcode);
}
